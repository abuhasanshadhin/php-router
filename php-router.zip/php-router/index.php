<?php

if (PHP_SESSION_ACTIVE != session_status()) {
    session_start();
}

error_reporting(0);
register_shutdown_function('shutdownError');

require './core/Request.php';
require './core/Router.php';

require './core/Validator.php';
require './core/helpers.php';
require './core/Template.php';
require './core/directive.php';

require './controllers/Controller.php';
require './controllers/UserController.php';

$router = new Shadhin\Router;

require './routes.php';

$res = $router->dispatch();

if (is_array($res) && isset($res['view'])) {
    $data = $res['data'];
    $contents = $res['contents'];
    count($data) > 0 ? extract($data) : '';
    $errors = $_SESSION['errors'] ?? [];
    $old = $_SESSION['oldData'] ?? [];
    eval("?> $contents");
    $_SESSION['errors'] = [];
    $_SESSION['oldData'] = [];
} else {
    print_r($res);
}


function shutdownError()
{
    $lasterror = error_get_last();
    switch ($lasterror['type']) {
        case E_ERROR:
        case E_CORE_ERROR:
        case E_COMPILE_ERROR:
        case E_USER_ERROR:
        case E_RECOVERABLE_ERROR:
        case E_CORE_WARNING:
        case E_COMPILE_WARNING:
        case E_PARSE:
            $header = "Error [{$lasterror['type']}]";
            $message = "<b>Message:</b> {$lasterror['message']}";
            $message .= "<br><br><b>File:</b> {$lasterror['file']}";
            $message .= "<br><br><b>Line:</b> {$lasterror['line']}";
            include './core/error.php';
    }
}
<?php

namespace Shadhin;

class Router
{
    public $routes = [];
    private $noMatch = true;

    public function get($url, $callback)
    {
        $this->addRoute('GET', $url, $callback);
        return $this;
    }

    public function post($url, $callback)
    {
        $this->addRoute('POST', $url, $callback);
        return $this;
    }

    public function name($name)
    {
        $lastRouteKey = array_key_last($this->routes);
        $this->routes[$lastRouteKey]['name'] = $name;
    }

    private function addRoute($method, $url, $callback)
    {
        $this->routes[] = [
            'method' => $method,
            'url' => $url,
            'callback' => $callback,
        ];
    }

    public function dispatch()
    {
        $requestUrl = $_SERVER['PATH_INFO'] ?? '/';
        $requestMethod = $_SERVER['REQUEST_METHOD'];
        foreach ($this->routes as $route) {
            $pattern = $this->getModifedPattern($route['url']);
            $matches = [];
            if (preg_match($pattern, $requestUrl, $matches)) {
                if ($requestMethod == $route['method']) {
                    $this->noMatch = false;
                    array_shift($matches);
                    if (is_callable($route['callback'])) {
                        return call_user_func_array($route['callback'], $matches);
                    } else {
                        return $this->invokeControllerMethod($route, $matches);
                    }
                }
            }
        }
        $this->checkRouteMatch();
    }

    private function checkRouteMatch()
    {
        if ($this->noMatch) {
            $requestUrl = $_SERVER['PATH_INFO'] ?? $_SERVER['REQUEST_URI'];
            $header = '404 Route Not Found';
            $message = "The route (<small>$requestUrl</small>) you requested was not matched";
            include './error.php';
        }
    }

    private function invokeControllerMethod($route, $matches)
    {
        if (is_array($route['callback']) && count($route['callback'])) {
            list($controller, $method) = $route['callback'];
        } else {
            if (strpos($route['callback'], '@') !== false) {
                list($controller, $method) = explode('@', $route['callback']);
            }
        }
        $controllerWithNamespace = "\Controllers\\{$controller}";
        $controllerObj = new $controllerWithNamespace;
        if (strtoupper($route['method']) == 'POST') {
            return $controllerObj->$method((new \Shadhin\Request), ...$matches);
        } else {
            return $controllerObj->$method(...$matches);
        }
    }

    private function getModifedPattern($requestedUrl)
    {
        $pattern = "@^" . preg_replace([
            '/\{[a-zA-Z0-9\_\-]+\}/',
            '/\{[a-zA-Z0-9\_\-]+\?\}/',
        ], [
            '([a-zA-Z0-9\-\_]+)',
            '?([a-zA-Z0-9\-\_]+)?',
        ], $requestedUrl) . "$@D";

        return $pattern;
    }
}

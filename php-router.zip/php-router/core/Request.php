<?php

namespace Shadhin;

class Request
{
    public function __construct()
    {
        if (isset($_POST) && count($_POST)) {
            foreach ($_POST as $key => $value) {
                $this->$key = $value;
            }
        }
    }
}
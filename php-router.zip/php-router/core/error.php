<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
    <style>
        body, p {
            margin: 0;
            padding: 0;
        }
        .container {
            box-shadow: 0px 0px 4px 1px #d0d0d0;
            margin: 5%;
            font-size: 1.3rem;
            border: 1px solid #d0d0d0;
            color: #444444;
            font-family: 'Arial';
        }
        .header {
            border-bottom: 2px solid #d0d0d0;
            letter-spacing: 1px;
            margin: 0;
            padding: 1% 2%;
        }
        .msg {
            padding: 1% 2%; 
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h4 class="header"><?= $header ?? '' ?></h4>
        <div class="msg">
            <p> <?= $message ?? '' ?> </p>
        </div>
    </div>
</body>
</html>
<?php

namespace Shadhin;

class Template
{
    public static $directives = [];
    private static $replaceWith = [];
    private static $inheritSections = [];

    public static function directive($name, $callback)
    {
        self::$directives[] = [trim($name), $callback];
    }

    public static function render($fileContents)
    {
        self::functionKeywordMatches($fileContents);
        self::printKeywordProcess($fileContents);

        if (count(self::$replaceWith)) {
            foreach (self::$replaceWith as $item) {
                $fileContents = str_replace(
                    $item['line'],
                    $item['replace'] . ($item['nl'] ? "\n" : ''),
                    $fileContents
                );
            }
        }

        return $fileContents;
    }

    private static function functionKeywordMatches($contents)
    {
        preg_match_all('/@(.*)\s?(\(.*\))?/', $contents, $matches);
        if (count($matches[0])) {
            foreach ($matches[0] as $key => $line) {
                preg_match('/@([a-zA-z]+)\s?(\(.*\))?/', $line, $tagArray);
                if (count($tagArray)) {
                    $tagArray = array_slice($tagArray, 1);
                    self::functionKeywordProcess($tagArray, $line);
                }
            }
        }
    }

    private function functionKeywordProcess($tagArray, $line)
    {
        foreach (self::$directives as $directive) {
            if ($directive[0] == $tagArray[0]) {
                $params = $tagArray[1] ?? '';
                $params = substr($params, 1);
                $length = strlen($params) - 1;
                $params = substr($params, 0, $length);
                $expression = $directive[1]($params);
                self::$replaceWith[] = [
                    'line' => $line,
                    'replace' => $expression,
                    'nl' => true,
                ];
            }
        }
    }

    private static function printKeywordProcess($contents)
    {
        self::printKeywordEntityProcess($contents, '/{{\s?(.*)\s?}}/', true);
        self::printKeywordEntityProcess($contents, '/{!!\s?(.*)\s?!!}/', false);
    }

    private static function printKeywordEntityProcess($contents, $pattern, $entity)
    {
        preg_match_all($pattern, $contents, $prints);
        list($tags, $expressions) = $prints;
        if (count($tags) == count($expressions)) {
            foreach ($tags as $key => $item) {
                $expression = trim($expressions[$key]);
                $exp = "<?php echo ";
                $exp .= $entity ? 'htmlentities' : '';
                $exp .= "($expression) ?>";
                self::$replaceWith[] = [
                    'line' => $item,
                    'replace' => $exp,
                    'nl' => false,
                ];
            }
        }
    }
}

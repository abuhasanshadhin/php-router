<?php

use Shadhin\Template;

function view($fileName, $data = [])
{
    $fileName = str_replace('.', '/', $fileName);
    $fileName = __DIR__ . "/../views/{$fileName}.view.php";
    $fileContents = file_get_contents($fileName);
    $contents = Template::render($fileContents);
    return [
        'view' => true,
        'data' => $data,
        'contents' => $contents
    ];
}

function route($name, $params = [])
{
    global $router;
    $notFound = true;
    if (isset($router->routes) && count($router->routes)) {
        foreach ($router->routes as $route) {
            if ($route['name'] == $name) {
                $notFound = false;
                $route = $route['url'];
                $pattern = '/\{[a-zA-Z0-9\_\-]+\}/';
                if (is_array($params)) {
                    foreach ($params as $item) {
                        $route = preg_replace($pattern, $item, $route, 1);
                    }
                } else {
                    $route = preg_replace($pattern, $params, $route);
                }
                return baseUrl() . $route;
            }
        }
    }
    if ($notFound) {
        $header = '404 Route Not Found';
        $message = "Route name (<small>{$name}</small>) not matched";
        include __DIR__ . './error.php';
        exit;
    }
}

function baseUrl()
{
    $directory = dirname($_SERVER['SCRIPT_NAME']);
    $directory = strlen($directory) > 1 ? $directory : '';
    $protocol = $_SERVER['REQUEST_SCHEME'];
    $protocol = $protocol ? $protocol . '://' : 'http://';
    return $protocol . $_SERVER['HTTP_HOST'] . $directory;
}

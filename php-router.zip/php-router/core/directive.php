<?php

use Shadhin\Template;

Template::directive('if', function ($expression) {
    return "<?php if ($expression) : ?>";
});

Template::directive('endif', function () {
    return "<?php endif; ?>";
});

Template::directive('isset', function ($expression) {
    return "<?php if (isset($expression)) { ?>";
});

Template::directive('endisset', function () {
    return "<?php } ?>";
});

Template::directive('foreach', function ($expression) {
    return "<?php foreach ($expression) { ?>";
});

Template::directive('endforeach', function () {
    return "<?php } ?>";
});

Template::directive('can', function ($expression) {
    return "<?php if ($expression == 'admin') { ?>";
});

Template::directive('cannot', function () {
    return "<?php } else { ?>";
});

Template::directive('endcan', function () {
    return "<?php } ?>";
});

Template::directive('exp', function ($exp) {
    return "<?php {$exp} ?>";
});

Template::directive('php', function () {
    return "<?php";
});

Template::directive('endphp', function () {
    return "?>";
});

Template::directive('include', function ($expression) {
    $fileName = str_replace('.', '/', trim($expression, "'"));
    $fileName = __DIR__ . "/../views/{$fileName}.view.php";
    $contents = file_get_contents($fileName);
    return Template::render($contents);
});
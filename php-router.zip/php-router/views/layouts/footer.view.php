<footer>
            <p>&copy; Template Compiler - 2020</p>
        </footer>
    </div>
</body>
</html>

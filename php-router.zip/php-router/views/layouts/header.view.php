<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template Compiler</title>
    <link rel="stylesheet" href="{{ baseUrl() }}/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Template Compiler</h1>
        </header>
        <nav>
            <ul>
                <li><a href="{{ route('home') }}">Home</a></li>
                <li><a href="{{ route('u.create') }}">Create</a></li>
                <li><a href="">About</a></li>
            </ul>
        </nav>

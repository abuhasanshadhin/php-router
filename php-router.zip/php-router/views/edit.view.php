@include('layouts.header')

<section class="content">
    <form action="{{ route('u.update', $id) }}" method="post">
        <table class="form">
            <tr>
                <td>Name</td>
                <td>:</td>
                <td><input type="text" name="name" value="{{ $user['name'] }}" id="name"></td>
            </tr>
            <tr>
                <td>Phone</td>
                <td>:</td>
                <td><input type="tel" name="phone" value="{{ $user['phone'] }}" id="phone"></td>
            </tr>
            <tr>
                <td>E-Mail</td>
                <td>:</td>
                <td><input type="email" name="email" value="{{ $user['email'] }}" id="email"></td>
            </tr>
            <tr>
                <td colspan="2"></td>
                <td><input type="submit" value="Update"></td>
            </tr>
        </table>
    </form>
</section>

@include('layouts.footer')

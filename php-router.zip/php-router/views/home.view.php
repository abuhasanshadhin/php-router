@include('layouts.header')

<section class="content">
    <table class="table">
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Phone</th>
            <th>E-Mail</th>
            <th>Actions</th>
        </tr>
        @exp($i = 1)
        @foreach ($data as $k => $person)
        <tr>
            <td>{{ $i++ }}</td>
            <td>{{ $person['name'] }}</td>
            <td>{{ $person['phone'] }}</td>
            <td>{{ $person['email'] }}</td>
            <td>
                <a href="{{ route('u.edit', $k) }}">Edit</a> |
                <a href="{{ route('u.delete', $k) }}" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        @endforeach
    </table>
</section>

@include('layouts.footer')

@include('layouts.header')

<section class="content">
    <form action="{{ route('u.store') }}" method="post">
        <table class="form">
            <tr>
                <td>Name</td>
                <td>:</td>
                <td>
                    <input type="text" name="name" value="{{ $old['name'] ?? '' }}" id="name">
                    <span class="error">
                        {!! $errors['name'] ?? '' !!}
                    </span>
                </td>
            </tr>
            <tr>
                <td>Phone</td>
                <td>:</td>
                <td>
                    <input type="tel" name="phone" value="{{ $old['phone'] ?? '' }}" id="phone">
                    <span class="error">
                        {!! $errors['phone'] ?? '' !!}
                    </span>
                </td>
            </tr>
            <tr>
                <td>E-Mail</td>
                <td>:</td>
                <td>
                    <input type="email" name="email" value="{{ $old['email'] ?? '' }}" id="email">
                    <span class="error">
                        {!! $errors['email'] ?? '' !!}
                    </span>
                </td>
            </tr>
            <tr>
                <td colspan="2"></td>
                <td><input type="submit" value="Submit"></td>
            </tr>
        </table>
    </form>
</section>

@include('layouts.footer')

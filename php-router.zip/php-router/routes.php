<?php

$router->get('/', ['UserController', 'index'])->name('home');
$router->get('/user/create', 'UserController@create')->name('u.create');
$router->post('/user/store', 'UserController@store')->name('u.store');
$router->get('/user/{id}/edit', 'UserController@edit')->name('u.edit');
$router->post('/user/{id}/update', 'UserController@update')->name('u.update');
$router->get('/user/{id}/delete', 'UserController@delete')->name('u.delete');
<?php

namespace Controllers;

use Shadhin\Validator;
use Controllers\Controller;

class UserController extends Controller
{
    public function index()
    {
        return view('home', [
            'data' => $_SESSION['users'] ?? []
        ]);
    }

    public function create()
    {
        return view('create');
    }

    public function store($request)
    {
        $v = new Validator;
        $errors = $v->make($request, [
            'name' => 'required',
            'phone' => 'required',
            'email' => 'required|email'
        ]);
        if ($v->fails()) {
            $_SESSION['errors'] = $errors;
            $_SESSION['oldData'] = (array) $request;
            header('Location: ' . route('u.create'));
            return;
        }
        if ($_SESSION['users']) {
            array_unshift($_SESSION['users'], (array) $request);
        } else {
            $_SESSION['users'][] = (array) $request;
        }
        header('Location: ' . route('home'));
    }

    public function edit($id)
    {
        return view('edit', [
            'id' => $id,
            'user' => $_SESSION['users'][$id]
        ]);
    }

    public function update($request, $id)
    {
        $_SESSION['users'][$id] = (array) $request;
        header('Location: ' . route('home'));
    }

    public function delete($id)
    {
        unset($_SESSION['users'][$id]);
        header('Location: ' . route('home'));
    }
}
